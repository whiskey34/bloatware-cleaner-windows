using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace DebloatWin;

// ---------- PowerShell bridge (Windows PowerShell 5.1 has the Appx module) ----------

static class Ps
{
    static readonly Regex TokenRx = new(@"^[A-Za-z0-9._~\-]+$", RegexOptions.Compiled);
    static readonly Regex PathRx = new(@"^[A-Za-z]:\\[^'""`$;|&<>\r\n]+$", RegexOptions.Compiled);

    /// <summary>Quote a package name for use inside a PowerShell script. Rejects anything unexpected.</summary>
    public static string Q(string v)
    {
        if (!TokenRx.IsMatch(v)) throw new InvalidOperationException($"Unsafe value rejected: {v}");
        return "'" + v + "'";
    }

    public static string QPath(string v)
    {
        if (!PathRx.IsMatch(v)) throw new InvalidOperationException($"Unsafe path rejected: {v}");
        return "'" + v + "'";
    }

    public static (int Code, string Out, string Err) Run(string script)
    {
        var full = "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';" +
                   "[Console]::OutputEncoding=[Text.Encoding]::UTF8;" + script;
        var enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(full));

        var psi = new ProcessStartInfo("powershell.exe",
            $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand {enc}")
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        using var p = Process.Start(psi) ?? throw new InvalidOperationException("Cannot start powershell.exe");
        var so = p.StandardOutput.ReadToEndAsync();
        var se = p.StandardError.ReadToEndAsync();
        p.WaitForExit();
        return (p.ExitCode, so.Result, se.Result);
    }

    public static T Query<T>(string script)
    {
        var r = Run(script);
        if (r.Code != 0) throw new InvalidOperationException(r.Err.Trim());
        return JsonSerializer.Deserialize<T>(r.Out, Json.Options)
               ?? throw new InvalidOperationException("Unexpected empty PowerShell output.");
    }
}

// ---------- Plan ----------

sealed class PkgDto
{
    public string Name { get; set; } = "";
    public string PackageFullName { get; set; } = "";
    public bool NonRemovable { get; set; }
}

sealed class ProvDto
{
    public string DisplayName { get; set; } = "";
    public string PackageName { get; set; } = "";
}

sealed class AppxTarget { public AppxItem Item = null!; public PkgDto Pkg = null!; }
sealed class ProvTarget { public AppxItem Item = null!; public ProvDto Pkg = null!; }
sealed class RegTarget { public RegistryItem Item = null!; public string Name = ""; public int Desired; public int? Current; }

sealed class Plan
{
    public List<AppxTarget> Appx { get; } = new();
    public List<ProvTarget> Prov { get; } = new();
    public List<RegTarget> Reg { get; } = new();
    public List<string> Notes { get; } = new();
    public bool IsEmpty => Appx.Count == 0 && Prov.Count == 0 && Reg.Count == 0;
}

static class Planner
{
    public static Plan Build(Catalog c, Options o)
    {
        if (o.Only != null)
        {
            var known = c.Appx.Select(a => a.Id).Concat(c.Registry.Select(r => r.Id))
                         .ToHashSet(StringComparer.OrdinalIgnoreCase);
            var unknown = o.Only.Where(x => !known.Contains(x)).ToList();
            if (unknown.Count > 0)
                throw new ArgumentException("Unknown id(s): " + string.Join(", ", unknown) + " (see: debloatwin list)");
        }

        bool Selected(string id, string risk) =>
            o.Only != null ? o.Only.Contains(id) : (risk == "safe" || (o.Optional && risk == "optional"));

        var plan = new Plan();
        var apps = c.Appx.Where(a => Selected(a.Id, a.Risk)).ToList();

        if (apps.Count > 0)
        {
            var installed = Ps.Query<List<PkgDto>>(
                "ConvertTo-Json -Compress -InputObject @(Get-AppxPackage | Select-Object Name,PackageFullName,NonRemovable)");

            foreach (var item in apps)
            {
                foreach (var pkg in installed.Where(p => CatalogLoader.NameMatches(item.Name, p.Name)))
                {
                    if (pkg.NonRemovable || CatalogLoader.IsProtected(pkg.Name))
                    {
                        plan.Notes.Add($"skipped {pkg.Name}: protected / non-removable");
                        continue;
                    }
                    plan.Appx.Add(new AppxTarget { Item = item, Pkg = pkg });
                }
            }

            if (o.Provisioned)
            {
                var prov = Ps.Query<List<ProvDto>>(
                    "ConvertTo-Json -Compress -InputObject @(Get-AppxProvisionedPackage -Online | Select-Object DisplayName,PackageName)");
                foreach (var item in apps)
                    foreach (var p in prov.Where(p => CatalogLoader.NameMatches(item.Name, p.DisplayName)
                                                      && !CatalogLoader.IsProtected(p.DisplayName)))
                        plan.Prov.Add(new ProvTarget { Item = item, Pkg = p });
            }
        }

        foreach (var item in c.Registry.Where(r => Selected(r.Id, r.Risk)))
        {
            foreach (var v in item.Values)
            {
                if (!TryReadDword(item.Path, v.Name, out var cur))
                {
                    plan.Notes.Add($"skipped {item.Id}/{v.Name}: existing value is not a DWORD");
                    continue;
                }
                if (cur == v.Data) continue; // already applied
                plan.Reg.Add(new RegTarget { Item = item, Name = v.Name, Desired = v.Data, Current = cur });
            }
        }

        return plan;
    }

    public static bool TryReadDword(string path, string name, out int? value)
    {
        value = null;
        using var k = Registry.CurrentUser.OpenSubKey(path);
        var v = k?.GetValue(name);
        if (v == null) return true;
        if (v is int i) { value = i; return true; }
        return false;
    }
}

// ---------- Executor + Undo ----------

static class Executor
{
    public static bool CreateRestorePoint(out string error)
    {
        var r = Ps.Run("Checkpoint-Computer -Description 'DebloatWin' -RestorePointType 'MODIFY_SETTINGS'");
        error = r.Err.Trim();
        return r.Code == 0;
    }

    public static Session Apply(Plan plan, string build)
    {
        var s = new Session { Id = DateTime.Now.ToString("yyyyMMdd-HHmmss"), StartedUtc = DateTime.UtcNow, WindowsBuild = build };

        foreach (var t in plan.Appx)
        {
            var rec = new ActionRecord { Type = "appx", Id = t.Item.Id, Target = t.Pkg.PackageFullName };
            Run(rec, () => Ps.Run($"Remove-AppxPackage -Package {Ps.Q(t.Pkg.PackageFullName)}"));
            Report(rec);
            s.Actions.Add(rec); s.Save();
        }

        foreach (var t in plan.Prov)
        {
            var rec = new ActionRecord { Type = "provisioned", Id = t.Item.Id, Target = t.Pkg.PackageName };
            Run(rec, () => Ps.Run($"Remove-AppxProvisionedPackage -Online -PackageName {Ps.Q(t.Pkg.PackageName)} | Out-Null"));
            Report(rec);
            s.Actions.Add(rec); s.Save();
        }

        foreach (var t in plan.Reg)
        {
            var rec = new ActionRecord
            {
                Type = "registry", Id = t.Item.Id, Target = t.Name,
                RegPath = t.Item.Path, Before = t.Current, After = t.Desired
            };
            try
            {
                using var key = Registry.CurrentUser.CreateSubKey(t.Item.Path, true);
                key.SetValue(t.Name, t.Desired, RegistryValueKind.DWord);
                rec.Status = "ok";
            }
            catch (Exception ex) { rec.Status = "failed"; rec.Error = ex.Message; }
            Report(rec);
            s.Actions.Add(rec); s.Save();
        }

        return s;
    }

    static void Run(ActionRecord rec, Func<(int Code, string Out, string Err)> action)
    {
        try
        {
            var r = action();
            if (r.Code == 0) rec.Status = "ok";
            else { rec.Status = "failed"; rec.Error = r.Err.Trim(); }
        }
        catch (Exception ex) { rec.Status = "failed"; rec.Error = ex.Message; }
    }

    static void Report(ActionRecord r)
    {
        var tag = r.Status == "ok" ? "  ok    " : "  FAILED";
        Console.WriteLine($"{tag} [{r.Type}] {r.Id}: {r.Target}");
        if (r.Error != null) Console.WriteLine("          " + r.Error.Split('\n')[0]);
    }

    public static void Undo(Session s)
    {
        foreach (var a in Enumerable.Reverse(s.Actions).Where(a => a.Status == "ok"))
        {
            switch (a.Type)
            {
                case "registry":
                    try
                    {
                        using var key = Registry.CurrentUser.CreateSubKey(a.RegPath!, true);
                        if (a.Before == null) key.DeleteValue(a.Target, false);
                        else key.SetValue(a.Target, a.Before.Value, RegistryValueKind.DWord);
                        Console.WriteLine($"  restored [registry] {a.Id}: {a.Target}");
                    }
                    catch (Exception ex) { Console.WriteLine($"  FAILED   [registry] {a.Id}: {a.Target} ({ex.Message})"); }
                    break;

                case "appx":
                    Console.WriteLine($"  manual   [appx] {a.Id}: reinstall '{a.Target.Split('_')[0]}' from the Microsoft Store");
                    break;

                case "provisioned":
                    Console.WriteLine($"  manual   [provisioned] {a.Id}: {a.Target.Split('_')[0]} cannot be re-provisioned automatically");
                    break;
            }
        }
    }
}
