using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DebloatWin;

public static class Json
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };
}

// ---------- Catalog ----------

public sealed class Catalog
{
    public List<AppxItem> Appx { get; set; } = new();
    public List<RegistryItem> Registry { get; set; } = new();
}

public sealed class AppxItem
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";      // package name; may end with '*'
    public string Title { get; set; } = "";
    public string Category { get; set; } = "";
    public string Risk { get; set; } = "safe";   // safe | optional
}

public sealed class RegValueDef
{
    public string Name { get; set; } = "";
    public int Data { get; set; }
}

public sealed class RegistryItem
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "safe";
    public string Path { get; set; } = "";       // under HKEY_CURRENT_USER
    public List<RegValueDef> Values { get; set; } = new();
}

// ---------- Session log (used by undo) ----------

public sealed class ActionRecord
{
    public string Type { get; set; } = "";       // appx | provisioned | registry
    public string Id { get; set; } = "";
    public string Target { get; set; } = "";     // package full name / registry value name
    public string? RegPath { get; set; }
    public int? Before { get; set; }             // null = value did not exist
    public int? After { get; set; }
    public string Status { get; set; } = "";     // ok | failed
    public string? Error { get; set; }
}

public sealed class Session
{
    public string Id { get; set; } = "";
    public DateTime StartedUtc { get; set; }
    public string WindowsBuild { get; set; } = "";
    public List<ActionRecord> Actions { get; set; } = new();

    public static string Dir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "DebloatWin", "sessions");

    public string FilePath => Path.Combine(Dir, Id + ".json");

    public void Save()
    {
        Directory.CreateDirectory(Dir);
        File.WriteAllText(FilePath, JsonSerializer.Serialize(this, Json.Options));
    }
}

// ---------- Loader + safety rules ----------

public static class CatalogLoader
{
    // Hard guard: names starting with any of these can never be removed,
    // even if someone adds them to catalog.json.
    static readonly string[] Protected =
    {
        "Microsoft.WindowsStore", "Microsoft.StorePurchaseApp", "Microsoft.DesktopAppInstaller",
        "Microsoft.SecHealthUI", "Microsoft.Windows.", "MicrosoftWindows.", "Windows.",
        "Microsoft.UI.Xaml", "Microsoft.VCLibs", "Microsoft.NET.", "Microsoft.WindowsAppRuntime",
        "Microsoft.Services.Store", "Microsoft.AAD.", "Microsoft.LockApp", "Microsoft.AccountsControl",
        "Microsoft.CredDialogHost", "Microsoft.ECApp", "Microsoft.AsyncTextService",
        "Microsoft.BioEnrollment", "Microsoft.Win32WebViewHost", "Microsoft.WidgetsPlatformRuntime",
        "Microsoft.MicrosoftEdge", "Microsoft.EdgeWebView"
    };

    static readonly Regex IdRx = new(@"^[a-z0-9\-]+$", RegexOptions.Compiled);
    static readonly Regex NameRx = new(@"^[A-Za-z0-9._\-]+\*?$", RegexOptions.Compiled);

    public static bool IsProtected(string packageName) =>
        Protected.Any(p => packageName.StartsWith(p, StringComparison.OrdinalIgnoreCase));

    public static bool NameMatches(string pattern, string actual) =>
        pattern.EndsWith('*')
            ? actual.StartsWith(pattern[..^1], StringComparison.OrdinalIgnoreCase)
            : actual.Equals(pattern, StringComparison.OrdinalIgnoreCase);

    public static Catalog Load()
    {
        string json;
        var external = Path.Combine(AppContext.BaseDirectory, "catalog.json");
        if (File.Exists(external))
        {
            json = File.ReadAllText(external);
        }
        else
        {
            using var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json")
                          ?? throw new InvalidOperationException("Embedded catalog.json not found.");
            using var r = new StreamReader(s);
            json = r.ReadToEnd();
        }

        var c = JsonSerializer.Deserialize<Catalog>(json, Json.Options)
                ?? throw new InvalidOperationException("catalog.json is empty.");
        Validate(c);
        return c;
    }

    static void Validate(Catalog c)
    {
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var a in c.Appx)
        {
            Check(ids, a.Id, a.Risk);
            if (!NameRx.IsMatch(a.Name) || a.Name.TrimEnd('*').Length < 6)
                throw new InvalidOperationException($"Catalog '{a.Id}': package name too broad or invalid: '{a.Name}'.");
            if (IsProtected(a.Name.TrimEnd('*')))
                throw new InvalidOperationException($"Catalog '{a.Id}': '{a.Name}' is a protected system package.");
        }

        foreach (var r in c.Registry)
        {
            Check(ids, r.Id, r.Risk);
            if (!r.Path.StartsWith(@"Software\", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Catalog '{r.Id}': registry path must be under HKCU\\Software.");
            if (r.Values.Count == 0 || r.Values.Any(v => string.IsNullOrWhiteSpace(v.Name)))
                throw new InvalidOperationException($"Catalog '{r.Id}': invalid registry values.");
        }
    }

    static void Check(HashSet<string> ids, string id, string risk)
    {
        if (!IdRx.IsMatch(id)) throw new InvalidOperationException($"Catalog: invalid id '{id}'.");
        if (!ids.Add(id)) throw new InvalidOperationException($"Catalog: duplicate id '{id}'.");
        if (risk != "safe" && risk != "optional")
            throw new InvalidOperationException($"Catalog '{id}': risk must be 'safe' or 'optional'.");
    }
}
