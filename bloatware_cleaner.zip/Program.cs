using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace DebloatWin;

sealed class Options
{
    public bool Optional, Provisioned, Yes, DryRun, SkipRestorePoint;
    public HashSet<string>? Only;
    public string? SessionRef;

    public static Options Parse(string[] a)
    {
        var o = new Options();
        for (int i = 0; i < a.Length; i++)
        {
            var x = a[i];
            string? val = null;
            var eq = x.IndexOf('=');
            if (eq > 0) { val = x[(eq + 1)..]; x = x[..eq]; }

            switch (x)
            {
                case "--optional": o.Optional = true; break;
                case "--provisioned": o.Provisioned = true; break;
                case "--yes": o.Yes = true; break;
                case "--dry-run": o.DryRun = true; break;
                case "--skip-restore-point": o.SkipRestorePoint = true; break;
                case "--only":
                    val ??= (++i < a.Length ? a[i] : throw new ArgumentException("--only needs a value"));
                    o.Only = val.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                                .ToHashSet(StringComparer.OrdinalIgnoreCase);
                    break;
                case "--session":
                    o.SessionRef = val ?? (++i < a.Length ? a[i] : throw new ArgumentException("--session needs a value"));
                    break;
                default: throw new ArgumentException($"Unknown option: {x}");
            }
        }
        return o;
    }
}

internal static class Program
{
    static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        if (args.Length == 0 || args[0] is "-h" or "--help" or "help") { Help(); return 0; }

        try
        {
            if (!OperatingSystem.IsWindows() || Environment.OSVersion.Version.Build < 22000)
            {
                Console.Error.WriteLine("This tool supports Windows 11 only.");
                return 2;
            }

            var cmd = args[0].ToLowerInvariant();
            var opt = Options.Parse(args.Skip(1).ToArray());
            var catalog = CatalogLoader.Load();

            return cmd switch
            {
                "list" => Commands.List(catalog),
                "scan" => Commands.Scan(catalog, opt),
                "apply" => Commands.Apply(catalog, opt),
                "undo" => Commands.Undo(opt),
                _ => Fail($"Unknown command: {cmd}")
            };
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("ERROR: " + ex.Message);
            return 1;
        }
    }

    static int Fail(string msg) { Console.Error.WriteLine(msg); Help(); return 2; }

    static void Help() => Console.WriteLine("""
        debloatwin - remove preinstalled Windows 11 apps and disable per-user promos (allowlist only)

        USAGE
          debloatwin list
          debloatwin scan   [--optional] [--only id,id] [--provisioned]
          debloatwin apply  [--optional] [--only id,id] [--provisioned] [--dry-run] [--yes] [--skip-restore-point]
          debloatwin undo   [--session <id|path>]

        NOTES
          scan / apply --dry-run never change anything.
          Default scope = items marked 'safe'. --optional adds 'optional' items.
          --only selects specific ids (works for optional items too).
          --provisioned also removes the provisioned copy so apps are not re-created for new users.
          Sessions are logged to %ProgramData%\DebloatWin\sessions and used by 'undo'.
        """);
}

static class Commands
{
    public static int List(Catalog c)
    {
        Console.WriteLine("APPS");
        foreach (var a in c.Appx) Console.WriteLine($"  [{a.Risk,-8}] {a.Id,-16} {a.Title}");
        Console.WriteLine("\nSETTINGS (current user, registry)");
        foreach (var r in c.Registry) Console.WriteLine($"  [{r.Risk,-8}] {r.Id,-16} {r.Title}");
        return 0;
    }

    public static int Scan(Catalog c, Options o)
    {
        Banner();
        var plan = Planner.Build(c, o);
        Print(plan);
        Console.WriteLine("\nScan only. Nothing was changed.");
        return 0;
    }

    public static int Apply(Catalog c, Options o)
    {
        Banner();
        var plan = Planner.Build(c, o);
        Print(plan);

        if (plan.IsEmpty) { Console.WriteLine("\nNothing to do."); return 0; }
        if (o.DryRun) { Console.WriteLine("\nDry run. Nothing was changed."); return 0; }

        if (!o.Yes)
        {
            Console.Write("\nType YES to continue: ");
            if (!string.Equals(Console.ReadLine()?.Trim(), "YES", StringComparison.Ordinal))
            {
                Console.WriteLine("Cancelled.");
                return 0;
            }
        }

        if (!o.SkipRestorePoint)
        {
            Console.WriteLine("\nCreating restore point...");
            if (!Executor.CreateRestorePoint(out var err))
            {
                Console.Error.WriteLine("Could not create a restore point: " + err);
                Console.Error.WriteLine("Enable System Protection, or re-run with --skip-restore-point to continue anyway.");
                return 1;
            }
        }

        Console.WriteLine("\nApplying...");
        var session = Executor.Apply(plan, BuildString());
        var failed = session.Actions.Count(a => a.Status != "ok");
        Console.WriteLine($"\nDone. {session.Actions.Count - failed} ok, {failed} failed. Session: {session.Id}");
        Console.WriteLine("Undo settings with: debloatwin undo");
        return failed == 0 ? 0 : 1;
    }

    public static int Undo(Options o)
    {
        string? file;
        if (o.SessionRef != null)
        {
            file = File.Exists(o.SessionRef) ? o.SessionRef
                 : Path.Combine(Session.Dir, o.SessionRef.EndsWith(".json") ? o.SessionRef : o.SessionRef + ".json");
        }
        else
        {
            file = Directory.Exists(Session.Dir)
                ? Directory.GetFiles(Session.Dir, "*.json").OrderBy(f => f).LastOrDefault()
                : null;
        }

        if (file == null || !File.Exists(file)) { Console.Error.WriteLine("No session found."); return 1; }

        var s = JsonSerializer.Deserialize<Session>(File.ReadAllText(file), Json.Options)
                ?? throw new InvalidOperationException("Invalid session file.");
        Console.WriteLine($"Undoing session {s.Id} ({s.Actions.Count} actions)\n");
        Executor.Undo(s);
        return 0;
    }

    static void Banner() => Console.WriteLine($"Windows 11 {BuildString()}\n");

    static string BuildString()
    {
        using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        var ver = k?.GetValue("DisplayVersion") ?? "";
        var build = k?.GetValue("CurrentBuild") ?? Environment.OSVersion.Version.Build;
        var ubr = k?.GetValue("UBR") ?? 0;
        return $"{ver} (build {build}.{ubr})".Trim();
    }

    static void Print(Plan p)
    {
        Console.WriteLine($"APPS for current user: {p.Appx.Count}");
        foreach (var t in p.Appx) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-16} {t.Pkg.PackageFullName}");

        if (p.Prov.Count > 0)
        {
            Console.WriteLine($"\nPROVISIONED packages: {p.Prov.Count}");
            foreach (var t in p.Prov) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-16} {t.Pkg.PackageName}");
        }

        Console.WriteLine($"\nREGISTRY values to change (HKCU): {p.Reg.Count}");
        foreach (var g in p.Reg.GroupBy(r => r.Item.Id))
            Console.WriteLine($"  [{g.First().Item.Risk,-8}] {g.Key,-16} {g.Count()} value(s)");

        foreach (var n in p.Notes) Console.WriteLine("  note: " + n);
    }
}
