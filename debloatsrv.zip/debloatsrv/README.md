# debloatsrv

Pembersih "bloatware" berbasis allowlist untuk **Windows Server 2019, 2022, 2025 dan yang lebih baru**
(Desktop Experience maupun Server Core). Aplikasi console .NET 8, dijalankan dari CMD sebagai Administrator.

## Build

```cmd
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Hasilnya `bin\Release\net8.0-windows\win-x64\publish\debloatsrv.exe` (satu file, tidak perlu install .NET di server).

## Pemakaian (CMD sebagai Administrator)

```cmd
debloatsrv list                      :: lihat semua item katalog
debloatsrv scan                      :: lihat rencana, tidak mengubah apa pun
debloatsrv scan --optional           :: termasuk item 'optional'
debloatsrv apply --dry-run           :: simulasi
debloatsrv apply                     :: jalankan item 'safe' (minta ketik YES)
debloatsrv apply --only diagtrack,telemetry
debloatsrv undo                      :: kembalikan sesi terakhir
```

Kode keluar: `0` sukses, `1` ada yang gagal / error, `2` OS tidak didukung atau argumen salah.

## Apa yang diubah

| Jenis    | Cara                                             | Undo otomatis |
|----------|--------------------------------------------------|---------------|
| Apps     | `Remove-AppxPackage` (dilewati di Server Core)   | Tidak         |
| Registry | DWORD di HKLM/HKCU `Software\...`                | Ya            |
| Service  | `sc config <svc> start= disabled` + `sc stop`    | Ya            |
| Feature  | `Disable-WindowsOptionalFeature -NoRestart`      | Ya            |

## Pengaman

- Hanya item di `catalog.json` yang bisa disentuh; `catalog.json` di samping .exe menimpa katalog bawaan.
- Daftar proteksi keras di `Models.cs` (WinRM, TermService, NTDS, DNS, Netlogon, NetFx, Hyper-V, dsb.) tidak bisa
  dimasukkan ke katalog.
- `skipIfRoles`: service dilewati jika role terkait terpasang (mis. Print Spooler di print server). Jika role tidak
  bisa dicek, service ikut dilewati.
- Windows Server tidak punya System Restore: buat snapshot VM / backup sebelum `apply`.
- Policy registry bisa ditimpa Group Policy domain.
- Log sesi: `%ProgramData%\DebloatSrv\sessions`.
