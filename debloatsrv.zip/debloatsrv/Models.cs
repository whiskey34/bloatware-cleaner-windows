using System.Reflection;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace DebloatSrv;

public static class Json
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };
}

// ---------- OS detection ----------

public static class OsInfo
{
    static string? Cv(string name)
    {
        using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        return k?.GetValue(name)?.ToString();
    }

    public static int Build => Environment.OSVersion.Version.Build;
    public static string InstallationType => Cv("InstallationType") ?? "";   // Client | Server | Server Core
    public static bool IsServer => InstallationType.StartsWith("Server", StringComparison.OrdinalIgnoreCase);
    public static bool IsServerCore => InstallationType.Equals("Server Core", StringComparison.OrdinalIgnoreCase);

    public static bool IsDomainController
    {
        get
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\ProductOptions");
            return string.Equals(k?.GetValue("ProductType") as string, "LanmanNt", StringComparison.OrdinalIgnoreCase);
        }
    }

    public static string Describe() =>
        $"{Cv("ProductName") ?? "Windows"} [{InstallationType}{(IsDomainController ? ", Domain Controller" : "")}] " +
        $"build {Cv("CurrentBuild") ?? Build.ToString()}.{Cv("UBR") ?? "0"}";
}

// ---------- Catalog ----------

public sealed class Catalog
{
    public List<AppxItem> Appx { get; set; } = new();
    public List<RegistryItem> Registry { get; set; } = new();
    public List<ServiceItem> Services { get; set; } = new();
    public List<FeatureItem> Features { get; set; } = new();
}

public sealed class AppxItem
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";       // package name; may end with '*'
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "safe";    // safe | optional
}

public sealed class RegValueDef
{
    public string Name { get; set; } = "";
    public int Data { get; set; }
}

public sealed class RegistryItem
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "safe";
    public string Hive { get; set; } = "HKLM";    // HKLM | HKCU
    public string Path { get; set; } = "";        // must start with Software\
    public List<RegValueDef> Values { get; set; } = new();

    public RegistryKey Root => Hive.Equals("HKCU", StringComparison.OrdinalIgnoreCase)
        ? Microsoft.Win32.Registry.CurrentUser
        : Microsoft.Win32.Registry.LocalMachine;
}

public sealed class ServiceItem
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "safe";
    public string Name { get; set; } = "";        // service short name, e.g. DiagTrack
    public List<string> SkipIfRoles { get; set; } = new();   // Get-WindowsFeature names; if installed, skip
}

public sealed class FeatureItem
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Risk { get; set; } = "safe";
    public string Name { get; set; } = "";        // Get-WindowsOptionalFeature name
}

// ---------- Session log (used by undo) ----------

public sealed class ActionRecord
{
    public string Type { get; set; } = "";        // appx | provisioned | registry | service | feature
    public string Id { get; set; } = "";
    public string Target { get; set; } = "";      // package / value / service / feature name
    public string? Hive { get; set; }
    public string? RegPath { get; set; }
    public int? Before { get; set; }              // registry: null = value did not exist
    public int? After { get; set; }
    public string? PrevStart { get; set; }        // service: auto | delayed-auto | demand
    public string Status { get; set; } = "";      // ok | failed
    public string? Error { get; set; }
}

public sealed class Session
{
    public string Id { get; set; } = "";
    public DateTime StartedUtc { get; set; }
    public string Os { get; set; } = "";
    public bool RestartNeeded { get; set; }
    public List<ActionRecord> Actions { get; set; } = new();

    public static string Dir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "DebloatSrv", "sessions");

    public string FilePath => Path.Combine(Dir, Id + ".json");

    public void Save()
    {
        Directory.CreateDirectory(Dir);
        File.WriteAllText(FilePath, JsonSerializer.Serialize(this, Json.Options));
    }
}

// ---------- Loader + safety rules ----------

public static class CatalogLoader
{
    // Hard guards: these can never be touched, even if someone adds them to catalog.json.
    static readonly string[] ProtectedAppx =
    {
        "Microsoft.WindowsStore", "Microsoft.DesktopAppInstaller", "Microsoft.SecHealthUI",
        "Microsoft.Windows.", "MicrosoftWindows.", "Windows.", "Microsoft.UI.Xaml", "Microsoft.VCLibs",
        "Microsoft.NET.", "Microsoft.WindowsAppRuntime", "Microsoft.AAD.", "Microsoft.LockApp",
        "Microsoft.AccountsControl", "Microsoft.CredDialogHost", "Microsoft.ECApp", "Microsoft.AsyncTextService",
        "Microsoft.BioEnrollment", "Microsoft.Win32WebViewHost", "Microsoft.MicrosoftEdge", "Microsoft.EdgeWebView"
    };

    // Losing any of these can lock you out of the server or break a role.
    static readonly HashSet<string> ProtectedServices = new(StringComparer.OrdinalIgnoreCase)
    {
        "RpcSs", "RpcEptMapper", "DcomLaunch", "LSM", "SamSs", "Netlogon", "NTDS", "DNS", "Dnscache", "Dhcp",
        "DHCPServer", "W32Time", "WinRM", "TermService", "SessionEnv", "UmRdpService", "EventLog", "mpssvc", "BFE",
        "CryptSvc", "wuauserv", "TrustedInstaller", "Winmgmt", "gpsvc", "ProfSvc", "Schedule", "PlugPlay", "Power",
        "nsi", "NlaSvc", "netprofm", "Netman", "LanmanServer", "LanmanWorkstation", "KeyIso", "VaultSvc", "WinDefend",
        "WdNisSvc", "SENS", "UserManager", "CoreMessagingRegistrar", "BrokerInfrastructure", "SystemEventsBroker",
        "StateRepository", "AppXSvc", "ClipSVC", "IKEEXT", "PolicyAgent", "Kdc", "IsmServ", "DFSR", "Dfs",
        "vmms", "vmcompute", "W3SVC", "WAS", "MSSQLSERVER", "ClusSvc", "VSS", "swprv", "wbengine", "TapiSrv"
    };

    static readonly string[] ProtectedFeatures =
    {
        "NetFx", "Server-Gui", "Server-Shell", "Windows-Defender", "Microsoft-Hyper-V", "DirectoryServices",
        "ActiveDirectory", "DNS-Server", "DHCPServer", "IIS-", "WindowsServerBackup", "FailoverCluster", "RSAT"
    };

    static readonly Regex IdRx = new(@"^[a-z0-9\-]+$", RegexOptions.Compiled);
    static readonly Regex NameRx = new(@"^[A-Za-z0-9._\-]+\*?$", RegexOptions.Compiled);
    static readonly Regex PlainNameRx = new(@"^[A-Za-z0-9._\-]+$", RegexOptions.Compiled);

    public static bool IsProtectedAppx(string packageName) =>
        ProtectedAppx.Any(p => packageName.StartsWith(p, StringComparison.OrdinalIgnoreCase));

    public static bool NameMatches(string pattern, string actual) =>
        pattern.EndsWith('*')
            ? actual.StartsWith(pattern[..^1], StringComparison.OrdinalIgnoreCase)
            : actual.Equals(pattern, StringComparison.OrdinalIgnoreCase);

    public static Catalog Load()
    {
        string json;
        var external = Path.Combine(AppContext.BaseDirectory, "catalog.json");
        if (File.Exists(external))
        {
            json = File.ReadAllText(external);
        }
        else
        {
            using var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("catalog.json")
                          ?? throw new InvalidOperationException("Embedded catalog.json not found.");
            using var r = new StreamReader(s);
            json = r.ReadToEnd();
        }
        return Parse(json);
    }

    public static Catalog Parse(string json)
    {
        var c = JsonSerializer.Deserialize<Catalog>(json, Json.Options)
                ?? throw new InvalidOperationException("catalog.json is empty.");
        Validate(c);
        return c;
    }

    static void Validate(Catalog c)
    {
        var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var a in c.Appx)
        {
            Check(ids, a.Id, a.Risk);
            if (!NameRx.IsMatch(a.Name) || a.Name.TrimEnd('*').Length < 6)
                throw new InvalidOperationException($"Catalog '{a.Id}': package name too broad or invalid: '{a.Name}'.");
            if (IsProtectedAppx(a.Name.TrimEnd('*')))
                throw new InvalidOperationException($"Catalog '{a.Id}': '{a.Name}' is a protected system package.");
        }

        foreach (var r in c.Registry)
        {
            Check(ids, r.Id, r.Risk);
            if (!r.Hive.Equals("HKLM", StringComparison.OrdinalIgnoreCase) && !r.Hive.Equals("HKCU", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Catalog '{r.Id}': hive must be HKLM or HKCU.");
            if (!r.Path.StartsWith(@"Software\", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Catalog '{r.Id}': registry path must be under Software\\.");
            if (r.Values.Count == 0 || r.Values.Any(v => string.IsNullOrWhiteSpace(v.Name)))
                throw new InvalidOperationException($"Catalog '{r.Id}': invalid registry values.");
        }

        foreach (var s in c.Services)
        {
            Check(ids, s.Id, s.Risk);
            if (!PlainNameRx.IsMatch(s.Name))
                throw new InvalidOperationException($"Catalog '{s.Id}': invalid service name '{s.Name}'.");
            if (ProtectedServices.Contains(s.Name))
                throw new InvalidOperationException($"Catalog '{s.Id}': '{s.Name}' is a protected service.");
            if (s.SkipIfRoles.Any(r => !PlainNameRx.IsMatch(r)))
                throw new InvalidOperationException($"Catalog '{s.Id}': invalid role name in skipIfRoles.");
        }

        foreach (var f in c.Features)
        {
            Check(ids, f.Id, f.Risk);
            if (!PlainNameRx.IsMatch(f.Name))
                throw new InvalidOperationException($"Catalog '{f.Id}': invalid feature name '{f.Name}'.");
            if (ProtectedFeatures.Any(p => f.Name.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException($"Catalog '{f.Id}': '{f.Name}' is a protected feature.");
        }
    }

    static void Check(HashSet<string> ids, string id, string risk)
    {
        if (!IdRx.IsMatch(id)) throw new InvalidOperationException($"Catalog: invalid id '{id}'.");
        if (!ids.Add(id)) throw new InvalidOperationException($"Catalog: duplicate id '{id}'.");
        if (risk != "safe" && risk != "optional")
            throw new InvalidOperationException($"Catalog '{id}': risk must be 'safe' or 'optional'.");
    }
}
