using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace DebloatSrv;

// ---------- Process bridge (Windows PowerShell 5.1 has the Appx, DISM and ServerManager modules) ----------

static class Ps
{
    static readonly Regex TokenRx = new(@"^[A-Za-z0-9._~\-]+$", RegexOptions.Compiled);

    /// <summary>Quote a name for use inside a PowerShell script. Rejects anything unexpected.</summary>
    public static string Q(string v)
    {
        if (!TokenRx.IsMatch(v)) throw new InvalidOperationException($"Unsafe value rejected: {v}");
        return "'" + v + "'";
    }

    public static string List(IEnumerable<string> v) => "@(" + string.Join(",", v.Select(Q)) + ")";

    public static (int Code, string Out, string Err) Run(string script)
    {
        var full = "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';" +
                   "[Console]::OutputEncoding=[Text.Encoding]::UTF8;" + script;
        var enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(full));
        return Exe("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc);
    }

    /// <summary>Run an executable with arguments passed as a list (no shell, no quoting issues).</summary>
    public static (int Code, string Out, string Err) Exe(string file, params string[] args)
    {
        var psi = new ProcessStartInfo(file)
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        foreach (var a in args) psi.ArgumentList.Add(a);

        using var p = Process.Start(psi) ?? throw new InvalidOperationException($"Cannot start {file}");
        var so = p.StandardOutput.ReadToEndAsync();
        var se = p.StandardError.ReadToEndAsync();
        p.WaitForExit();
        return (p.ExitCode, so.Result, se.Result);
    }

    public static T Query<T>(string script)
    {
        var r = Run(script);
        if (r.Code != 0) throw new InvalidOperationException(r.Err.Trim());
        return JsonSerializer.Deserialize<T>(r.Out, Json.Options)
               ?? throw new InvalidOperationException("Unexpected empty PowerShell output.");
    }
}

// ---------- Plan ----------

sealed class PkgDto
{
    public string Name { get; set; } = "";
    public string PackageFullName { get; set; } = "";
    public bool NonRemovable { get; set; }
}

sealed class ProvDto
{
    public string DisplayName { get; set; } = "";
    public string PackageName { get; set; } = "";
}

sealed class NameStateDto
{
    public string Name { get; set; } = "";
    public string State { get; set; } = "";
}

sealed class AppxTarget { public AppxItem Item = null!; public PkgDto Pkg = null!; }
sealed class ProvTarget { public AppxItem Item = null!; public ProvDto Pkg = null!; }
sealed class RegTarget { public RegistryItem Item = null!; public string Name = ""; public int Desired; public int? Current; }
sealed class SvcTarget { public ServiceItem Item = null!; public string Current = ""; }
sealed class FeatTarget { public FeatureItem Item = null!; }

sealed class Plan
{
    public List<AppxTarget> Appx { get; } = new();
    public List<ProvTarget> Prov { get; } = new();
    public List<RegTarget> Reg { get; } = new();
    public List<SvcTarget> Svc { get; } = new();
    public List<FeatTarget> Feat { get; } = new();
    public List<string> Notes { get; } = new();
    public bool IsEmpty => Appx.Count == 0 && Prov.Count == 0 && Reg.Count == 0 && Svc.Count == 0 && Feat.Count == 0;
}

static class Planner
{
    public static Plan Build(Catalog c, Options o)
    {
        if (o.Only != null)
        {
            var known = c.Appx.Select(a => a.Id).Concat(c.Registry.Select(r => r.Id))
                         .Concat(c.Services.Select(s => s.Id)).Concat(c.Features.Select(f => f.Id))
                         .ToHashSet(StringComparer.OrdinalIgnoreCase);
            var unknown = o.Only.Where(x => !known.Contains(x)).ToList();
            if (unknown.Count > 0)
                throw new ArgumentException("Unknown id(s): " + string.Join(", ", unknown) + " (see: debloatsrv list)");
        }

        bool Selected(string id, string risk) =>
            o.Only != null ? o.Only.Contains(id) : (risk == "safe" || (o.Optional && risk == "optional"));

        var plan = new Plan();
        PlanAppx(plan, c.Appx.Where(a => Selected(a.Id, a.Risk)).ToList(), o);
        PlanRegistry(plan, c.Registry.Where(r => Selected(r.Id, r.Risk)));
        PlanServices(plan, c.Services.Where(s => Selected(s.Id, s.Risk)).ToList());
        PlanFeatures(plan, c.Features.Where(f => Selected(f.Id, f.Risk)).ToList());
        return plan;
    }

    static void PlanAppx(Plan plan, List<AppxItem> apps, Options o)
    {
        if (apps.Count == 0) return;
        if (OsInfo.IsServerCore) { plan.Notes.Add("apps skipped: Server Core has no desktop apps"); return; }

        List<PkgDto> installed;
        try
        {
            installed = Ps.Query<List<PkgDto>>(
                "ConvertTo-Json -Compress -InputObject @(Get-AppxPackage | Select-Object Name,PackageFullName,NonRemovable)");
        }
        catch (Exception ex) { plan.Notes.Add("apps skipped: Appx query failed: " + FirstLine(ex.Message)); return; }

        foreach (var item in apps)
            foreach (var pkg in installed.Where(p => CatalogLoader.NameMatches(item.Name, p.Name)))
            {
                if (pkg.NonRemovable || CatalogLoader.IsProtectedAppx(pkg.Name))
                {
                    plan.Notes.Add($"skipped {pkg.Name}: protected / non-removable");
                    continue;
                }
                plan.Appx.Add(new AppxTarget { Item = item, Pkg = pkg });
            }

        if (!o.Provisioned) return;
        try
        {
            var prov = Ps.Query<List<ProvDto>>(
                "ConvertTo-Json -Compress -InputObject @(Get-AppxProvisionedPackage -Online | Select-Object DisplayName,PackageName)");
            foreach (var item in apps)
                foreach (var p in prov.Where(p => CatalogLoader.NameMatches(item.Name, p.DisplayName)
                                                  && !CatalogLoader.IsProtectedAppx(p.DisplayName)))
                    plan.Prov.Add(new ProvTarget { Item = item, Pkg = p });
        }
        catch (Exception ex) { plan.Notes.Add("provisioned skipped: query failed: " + FirstLine(ex.Message)); }
    }

    static void PlanRegistry(Plan plan, IEnumerable<RegistryItem> items)
    {
        foreach (var item in items)
            foreach (var v in item.Values)
            {
                if (!TryReadDword(item.Root, item.Path, v.Name, out var cur))
                {
                    plan.Notes.Add($"skipped {item.Id}/{v.Name}: existing value is not a DWORD");
                    continue;
                }
                if (cur == v.Data) continue; // already applied
                plan.Reg.Add(new RegTarget { Item = item, Name = v.Name, Desired = v.Data, Current = cur });
            }
    }

    static void PlanServices(Plan plan, List<ServiceItem> items)
    {
        if (items.Count == 0) return;

        // Role guard: if we cannot ask Server Manager, assume the role IS installed and skip.
        var roleNames = items.SelectMany(s => s.SkipIfRoles).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        HashSet<string>? installedRoles = new(StringComparer.OrdinalIgnoreCase);
        if (roleNames.Count > 0)
        {
            try
            {
                installedRoles = Ps.Query<List<NameStateDto>>(
                        "Import-Module ServerManager;" +
                        $"$r = Get-WindowsFeature -Name {Ps.List(roleNames)} | ForEach-Object {{ [pscustomobject]@{{Name=$_.Name; State=\"$($_.Installed)\"}} }};" +
                        "ConvertTo-Json -Compress -InputObject @($r)")
                    .Where(r => r.State == "True").Select(r => r.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                installedRoles = null;
                plan.Notes.Add("could not check installed roles: " + FirstLine(ex.Message));
            }
        }

        foreach (var item in items)
        {
            var cur = ReadStartType(item.Name);
            if (cur == null) { plan.Notes.Add($"skipped {item.Id}: service '{item.Name}' not present"); continue; }
            if (cur == "disabled") continue; // already applied
            if (cur is "boot" or "system") { plan.Notes.Add($"skipped {item.Id}: '{item.Name}' is a driver"); continue; }

            var blocking = installedRoles == null ? item.SkipIfRoles : item.SkipIfRoles.Where(installedRoles.Contains).ToList();
            if (blocking.Count > 0)
            {
                plan.Notes.Add($"skipped {item.Id}: role {string.Join(", ", blocking)} installed or unknown");
                continue;
            }
            plan.Svc.Add(new SvcTarget { Item = item, Current = cur });
        }
    }

    static void PlanFeatures(Plan plan, List<FeatureItem> items)
    {
        if (items.Count == 0) return;

        List<NameStateDto> states;
        try
        {
            // Unknown feature names throw on some builds and return nothing on others; treat both as "not present".
            states = Ps.Query<List<NameStateDto>>(
                $"$r = foreach ($n in {Ps.List(items.Select(f => f.Name))}) {{" +
                " try { $f = Get-WindowsOptionalFeature -Online -FeatureName $n;" +
                " if ($f) { [pscustomobject]@{Name=$f.FeatureName; State=\"$($f.State)\"} } } catch {} };" +
                "ConvertTo-Json -Compress -InputObject @($r)");
        }
        catch (Exception ex) { plan.Notes.Add("features skipped: query failed: " + FirstLine(ex.Message)); return; }

        foreach (var item in items)
        {
            var s = states.FirstOrDefault(x => x.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase));
            if (s == null) { plan.Notes.Add($"skipped {item.Id}: feature '{item.Name}' not present on this build"); continue; }
            if (s.State != "Enabled") continue; // already off
            plan.Feat.Add(new FeatTarget { Item = item });
        }
    }

    public static bool TryReadDword(RegistryKey root, string path, string name, out int? value)
    {
        value = null;
        using var k = root.OpenSubKey(path);
        var v = k?.GetValue(name);
        if (v == null) return true;
        if (v is int i) { value = i; return true; }
        return false;
    }

    /// <summary>Returns auto | delayed-auto | demand | disabled | boot | system, or null if the service does not exist.</summary>
    public static string? ReadStartType(string service)
    {
        using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\" + service);
        if (k?.GetValue("Start") is not int start) return null;
        return start switch
        {
            0 => "boot",
            1 => "system",
            2 => k.GetValue("DelayedAutostart") is int d && d == 1 ? "delayed-auto" : "auto",
            3 => "demand",
            _ => "disabled"
        };
    }

    public static string FirstLine(string s) => s.Trim().Split('\n')[0].Trim();
}

// ---------- Executor + Undo ----------

static class Executor
{
    public static Session Apply(Plan plan)
    {
        var s = new Session { Id = DateTime.Now.ToString("yyyyMMdd-HHmmss"), StartedUtc = DateTime.UtcNow, Os = OsInfo.Describe() };

        void Done(ActionRecord rec) { Report(rec); s.Actions.Add(rec); s.Save(); }

        foreach (var t in plan.Appx)
        {
            var rec = new ActionRecord { Type = "appx", Id = t.Item.Id, Target = t.Pkg.PackageFullName };
            Run(rec, () => Ps.Run($"Remove-AppxPackage -Package {Ps.Q(t.Pkg.PackageFullName)}"));
            Done(rec);
        }

        foreach (var t in plan.Prov)
        {
            var rec = new ActionRecord { Type = "provisioned", Id = t.Item.Id, Target = t.Pkg.PackageName };
            Run(rec, () => Ps.Run($"Remove-AppxProvisionedPackage -Online -PackageName {Ps.Q(t.Pkg.PackageName)} | Out-Null"));
            Done(rec);
        }

        foreach (var t in plan.Reg)
        {
            var rec = new ActionRecord
            {
                Type = "registry", Id = t.Item.Id, Target = t.Name,
                Hive = t.Item.Hive.ToUpperInvariant(), RegPath = t.Item.Path, Before = t.Current, After = t.Desired
            };
            try
            {
                using var key = t.Item.Root.CreateSubKey(t.Item.Path, true);
                key.SetValue(t.Name, t.Desired, RegistryValueKind.DWord);
                rec.Status = "ok";
            }
            catch (Exception ex) { rec.Status = "failed"; rec.Error = ex.Message; }
            Done(rec);
        }

        foreach (var t in plan.Svc)
        {
            var rec = new ActionRecord { Type = "service", Id = t.Item.Id, Target = t.Item.Name, PrevStart = t.Current };
            Run(rec, () => Ps.Exe("sc.exe", "config", t.Item.Name, "start=", "disabled"));
            if (rec.Status == "ok") Ps.Exe("sc.exe", "stop", t.Item.Name); // best effort; fails harmlessly if already stopped
            Done(rec);
        }

        foreach (var t in plan.Feat)
        {
            var rec = new ActionRecord { Type = "feature", Id = t.Item.Id, Target = t.Item.Name };
            Run(rec, () =>
            {
                var r = Ps.Run($"(Disable-WindowsOptionalFeature -Online -FeatureName {Ps.Q(t.Item.Name)} -NoRestart -WarningAction SilentlyContinue).RestartNeeded");
                if (r.Code == 0 && r.Out.Trim().Equals("True", StringComparison.OrdinalIgnoreCase)) s.RestartNeeded = true;
                return r;
            });
            Done(rec);
        }

        return s;
    }

    static void Run(ActionRecord rec, Func<(int Code, string Out, string Err)> action)
    {
        try
        {
            var r = action();
            if (r.Code == 0) rec.Status = "ok";
            else { rec.Status = "failed"; rec.Error = (r.Err + "\n" + r.Out).Trim(); }
        }
        catch (Exception ex) { rec.Status = "failed"; rec.Error = ex.Message; }
    }

    static void Report(ActionRecord r)
    {
        var tag = r.Status == "ok" ? "  ok    " : "  FAILED";
        Console.WriteLine($"{tag} [{r.Type}] {r.Id}: {r.Target}");
        if (r.Error != null) Console.WriteLine("          " + Planner.FirstLine(r.Error));
    }

    public static void Undo(Session s)
    {
        var restart = false;
        foreach (var a in Enumerable.Reverse(s.Actions).Where(a => a.Status == "ok"))
        {
            switch (a.Type)
            {
                case "registry":
                    try
                    {
                        var root = a.Hive == "HKCU" ? Registry.CurrentUser : Registry.LocalMachine;
                        using var key = root.CreateSubKey(a.RegPath!, true);
                        if (a.Before == null) key.DeleteValue(a.Target, false);
                        else key.SetValue(a.Target, a.Before.Value, RegistryValueKind.DWord);
                        Console.WriteLine($"  restored [registry] {a.Id}: {a.Hive}\\{a.RegPath}\\{a.Target}");
                    }
                    catch (Exception ex) { Console.WriteLine($"  FAILED   [registry] {a.Id}: {a.Target} ({ex.Message})"); }
                    break;

                case "service":
                    var start = a.PrevStart ?? "demand";
                    var r = Ps.Exe("sc.exe", "config", a.Target, "start=", start);
                    if (r.Code == 0 && start is "auto" or "delayed-auto") Ps.Exe("sc.exe", "start", a.Target);
                    Console.WriteLine(r.Code == 0
                        ? $"  restored [service] {a.Id}: {a.Target} -> {start}"
                        : $"  FAILED   [service] {a.Id}: {a.Target} ({Planner.FirstLine(r.Out + r.Err)})");
                    break;

                case "feature":
                    var f = Ps.Run($"(Enable-WindowsOptionalFeature -Online -FeatureName {Ps.Q(a.Target)} -All -NoRestart -WarningAction SilentlyContinue).RestartNeeded");
                    if (f.Code == 0 && f.Out.Trim().Equals("True", StringComparison.OrdinalIgnoreCase)) restart = true;
                    Console.WriteLine(f.Code == 0
                        ? $"  restored [feature] {a.Id}: {a.Target}"
                        : $"  FAILED   [feature] {a.Id}: {a.Target} ({Planner.FirstLine(f.Err)})");
                    break;

                case "appx":
                case "provisioned":
                    Console.WriteLine($"  manual   [{a.Type}] {a.Id}: {a.Target.Split('_')[0]} (no Microsoft Store on Server; reinstall with Add-AppxPackage)");
                    break;
            }
        }
        if (restart) Console.WriteLine("\nA restart is required to finish re-enabling features.");
    }
}
