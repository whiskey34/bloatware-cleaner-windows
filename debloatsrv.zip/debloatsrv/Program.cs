using System.Text;
using System.Text.Json;

namespace DebloatSrv;

sealed class Options
{
    public bool Optional, Provisioned, Yes, DryRun;
    public HashSet<string>? Only;
    public string? SessionRef;

    public static Options Parse(string[] a)
    {
        var o = new Options();
        for (int i = 0; i < a.Length; i++)
        {
            var x = a[i];
            string? val = null;
            var eq = x.IndexOf('=');
            if (eq > 0) { val = x[(eq + 1)..]; x = x[..eq]; }

            switch (x)
            {
                case "--optional": o.Optional = true; break;
                case "--provisioned": o.Provisioned = true; break;
                case "--yes": o.Yes = true; break;
                case "--dry-run": o.DryRun = true; break;
                case "--only":
                    val ??= (++i < a.Length ? a[i] : throw new ArgumentException("--only needs a value"));
                    o.Only = val.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                                .ToHashSet(StringComparer.OrdinalIgnoreCase);
                    break;
                case "--session":
                    o.SessionRef = val ?? (++i < a.Length ? a[i] : throw new ArgumentException("--session needs a value"));
                    break;
                default: throw new ArgumentException($"Unknown option: {x}");
            }
        }
        return o;
    }
}

internal static class Program
{
    const int MinBuild = 17763; // Windows Server 2019

    static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;

        if (args.Length == 0 || args[0] is "-h" or "--help" or "help" or "/?") { Help(); return 0; }

        try
        {
            if (!OperatingSystem.IsWindows() || !OsInfo.IsServer || OsInfo.Build < MinBuild)
            {
                Console.Error.WriteLine("This tool supports Windows Server 2019, 2022, 2025 and newer only.");
                Console.Error.WriteLine("Detected: " + (OperatingSystem.IsWindows() ? OsInfo.Describe() : Environment.OSVersion.ToString()));
                return 2;
            }

            var cmd = args[0].ToLowerInvariant();
            var opt = Options.Parse(args.Skip(1).ToArray());
            var catalog = CatalogLoader.Load();

            return cmd switch
            {
                "list" => Commands.List(catalog),
                "scan" => Commands.Scan(catalog, opt),
                "apply" => Commands.Apply(catalog, opt),
                "undo" => Commands.Undo(opt),
                _ => Fail($"Unknown command: {cmd}")
            };
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("ERROR: " + ex.Message);
            return 1;
        }
    }

    static int Fail(string msg) { Console.Error.WriteLine(msg); Help(); return 2; }

    static void Help() => Console.WriteLine("""
        debloatsrv - remove clutter from Windows Server 2019 / 2022 / 2025+ (allowlist only)

        USAGE
          debloatsrv list
          debloatsrv scan   [--optional] [--only id,id] [--provisioned]
          debloatsrv apply  [--optional] [--only id,id] [--provisioned] [--dry-run] [--yes]
          debloatsrv undo   [--session <id|path>]

        NOTES
          scan / apply --dry-run never change anything.
          Default scope = items marked 'safe'. --optional adds 'optional' items.
          --only selects specific ids (works for optional items too).
          --provisioned also removes the provisioned app copy so it is not re-created for new users.
          Windows Server has no System Restore: take a VM snapshot or backup before 'apply'.
          Domain Group Policy may override the registry policies this tool sets.
          Sessions are logged to %ProgramData%\DebloatSrv\sessions and used by 'undo'.
        """);
}

static class Commands
{
    public static int List(Catalog c)
    {
        Console.WriteLine("APPS (Desktop Experience only)");
        foreach (var a in c.Appx) Console.WriteLine($"  [{a.Risk,-8}] {a.Id,-20} {a.Title}");
        Console.WriteLine("\nREGISTRY");
        foreach (var r in c.Registry) Console.WriteLine($"  [{r.Risk,-8}] {r.Id,-20} {r.Title} ({r.Hive})");
        Console.WriteLine("\nSERVICES (disable + stop)");
        foreach (var s in c.Services) Console.WriteLine($"  [{s.Risk,-8}] {s.Id,-20} {s.Title} ({s.Name})");
        Console.WriteLine("\nFEATURES (disable)");
        foreach (var f in c.Features) Console.WriteLine($"  [{f.Risk,-8}] {f.Id,-20} {f.Title} ({f.Name})");
        return 0;
    }

    public static int Scan(Catalog c, Options o)
    {
        Banner();
        Print(Planner.Build(c, o));
        Console.WriteLine("\nScan only. Nothing was changed.");
        return 0;
    }

    public static int Apply(Catalog c, Options o)
    {
        Banner();
        var plan = Planner.Build(c, o);
        Print(plan);

        if (plan.IsEmpty) { Console.WriteLine("\nNothing to do."); return 0; }
        if (o.DryRun) { Console.WriteLine("\nDry run. Nothing was changed."); return 0; }

        if (!o.Yes)
        {
            Console.WriteLine("\nWindows Server has no System Restore. Make sure you have a VM snapshot or backup.");
            Console.Write("Type YES to continue: ");
            if (!string.Equals(Console.ReadLine()?.Trim(), "YES", StringComparison.Ordinal))
            {
                Console.WriteLine("Cancelled.");
                return 0;
            }
        }

        Console.WriteLine("\nApplying...");
        var session = Executor.Apply(plan);
        var failed = session.Actions.Count(a => a.Status != "ok");
        Console.WriteLine($"\nDone. {session.Actions.Count - failed} ok, {failed} failed. Session: {session.Id}");
        if (session.RestartNeeded) Console.WriteLine("A restart is required to finish disabling features.");
        Console.WriteLine("Undo with: debloatsrv undo");
        return failed == 0 ? 0 : 1;
    }

    public static int Undo(Options o)
    {
        string? file;
        if (o.SessionRef != null)
        {
            file = File.Exists(o.SessionRef) ? o.SessionRef
                 : Path.Combine(Session.Dir, o.SessionRef.EndsWith(".json") ? o.SessionRef : o.SessionRef + ".json");
        }
        else
        {
            file = Directory.Exists(Session.Dir)
                ? Directory.GetFiles(Session.Dir, "*.json").OrderBy(f => f).LastOrDefault()
                : null;
        }

        if (file == null || !File.Exists(file)) { Console.Error.WriteLine("No session found."); return 1; }

        var s = JsonSerializer.Deserialize<Session>(File.ReadAllText(file), Json.Options)
                ?? throw new InvalidOperationException("Invalid session file.");
        Console.WriteLine($"Undoing session {s.Id} ({s.Actions.Count} actions)\n");
        Executor.Undo(s);
        return 0;
    }

    static void Banner()
    {
        Console.WriteLine(OsInfo.Describe());
        if (OsInfo.IsDomainController) Console.WriteLine("WARNING: this is a Domain Controller. Review the plan carefully.");
        Console.WriteLine();
    }

    static void Print(Plan p)
    {
        Console.WriteLine($"APPS for current user: {p.Appx.Count}");
        foreach (var t in p.Appx) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-20} {t.Pkg.PackageFullName}");

        if (p.Prov.Count > 0)
        {
            Console.WriteLine($"\nPROVISIONED packages: {p.Prov.Count}");
            foreach (var t in p.Prov) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-20} {t.Pkg.PackageName}");
        }

        Console.WriteLine($"\nREGISTRY values to change: {p.Reg.Count}");
        foreach (var g in p.Reg.GroupBy(r => r.Item.Id))
            Console.WriteLine($"  [{g.First().Item.Risk,-8}] {g.Key,-20} {g.Count()} value(s) in {g.First().Item.Hive}");

        Console.WriteLine($"\nSERVICES to disable: {p.Svc.Count}");
        foreach (var t in p.Svc) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-20} {t.Item.Name} (now: {t.Current})");

        Console.WriteLine($"\nFEATURES to disable: {p.Feat.Count}");
        foreach (var t in p.Feat) Console.WriteLine($"  [{t.Item.Risk,-8}] {t.Item.Id,-20} {t.Item.Name}");

        if (p.Notes.Count > 0) Console.WriteLine();
        foreach (var n in p.Notes) Console.WriteLine("  note: " + n);
    }
}
